# Curso dde HTML 5 e CSS 3

Este repositório contem os códigos das páginas utilizadas na aulas de Programação WEB. Este é um curso básico de introdução à linguagem de marcação HTML5, de CSS3 e do framework Bootstrap3.

## Conteúdo

- Esta pasta contem as páginas de modelo utilizadas no curso. Neste pasta estão os CSS básicos, as imagens e os quatro arquivos de modelo.
